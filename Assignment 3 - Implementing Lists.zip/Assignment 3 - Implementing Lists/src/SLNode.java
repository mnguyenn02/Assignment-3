public class SLNode {
    Book book;
    SLNode next;

    public SLNode(Book book) {
        this.book = book;
        this.next = null;
    }
}
