public class AList {
    private Book[] books;
    private int size;
    private int maxSize;

    public AList() {
        maxSize = 5;
        books = new Book[maxSize];
        size = 0;

    }

    public void listAdd(Book p) {

        if(size == maxSize) {
            resize();
        }
        books[size++] = p;
    }

    private void resize() {

        maxSize *= 2;
        Book[] nBooks = new Book[maxSize];

        for(int i = 0; i < size; i++) {
            nBooks[i] = books[i];
        }

        books = nBooks;
    }

    public void listRemove(int pos) {

        if(pos < 0 || pos >= size) {
            return;
        }
        for(int i = pos; i < size - 1; i++) {
            books[i] = books[i + 1];
        }
        size--;
    }

    public String toString() {

        String string = "";

        for(int i = 0; i < size; i++) {
            string += books[i].toString() + "\n";
        }

        return string;
    }

}
