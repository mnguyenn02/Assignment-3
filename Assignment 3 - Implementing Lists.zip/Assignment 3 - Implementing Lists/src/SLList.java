public class SLList {

    private SLNode head;

    public SLList() {
        head = null;
    }

    public void listAdd(Book p) {

        SLNode nNode = new SLNode(p);

        if(head == null) {
            head = nNode;
        }
        else{
            SLNode temp = head;
            while(temp.next != null) {
                temp = temp.next;
            }
            temp.next = nNode;

        }
    }

    public void listRemove(int pos) {

        if (pos < 0 || head == null) {
            return;
        }
        if (pos == 0) {
            head = head.next;
            return;
        }

        SLNode temp = head;

        for (int i = 0; temp != null && i < pos - 1; i++) {
            temp = temp.next;
        }
        if (temp == null || temp.next == null) {
            return;
    }
        temp.next = temp.next.next;
    }

    public String toString() {

        String string = "";
        SLNode temp = head;

        while(temp != null) {
            string += temp.book.toString() + "\n";
            temp = temp.next;
        }
        return string;
    }


}
