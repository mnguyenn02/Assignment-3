public class DLList {

    private DLNode head;

    public DLList() {
        head = null;
    }

    public void listAdd(Book p) {

        DLNode nNode = new DLNode(p);

        if(head == null) {
            head = nNode;
        }
        else {

            DLNode temp = head;

            while(temp.next != null) {
                temp = temp.next;
            }
            temp.next = nNode;
            nNode.prev = temp;
        }
    }

    public void listRemove(int pos) {

        if(pos < 0 || head == null)
            return;

        if(pos == 0) {
            head = head.next;
            if(head != null)
                head.prev = null;
            return;
        }

        DLNode temp = head;

        for(int i = 0; temp != null && i < pos - 1; i++) {
            temp = temp.next;
        }
        if(temp == null)
            return;

        DLNode prevNode = temp.prev;
        DLNode nextNode = temp.next;

        if(prevNode != null)
            prevNode.next = nextNode;
        if(nextNode != null)
            nextNode.prev = prevNode;

    }

    public String toString() {

        String string = "";
        DLNode temp = head;

        while(temp != null) {
            string += temp.book.toString() + "\n";
            temp = temp.next;
        }
        return string;
    }



}
