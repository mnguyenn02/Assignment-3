public class Book {
    //Attributes
    String title;
    String author;
    Double price;

    public Book(String title, String author, Double price) {

        this.title = title;
        this.author = author;
        this.price = price;

    }


}
