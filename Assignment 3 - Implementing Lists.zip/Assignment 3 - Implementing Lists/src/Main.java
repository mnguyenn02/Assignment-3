public class Main {

    public static void main(String[] args) {

        Book book1 = new Book("wireless networks", "Anke Berr", 14.99);
        Book book2 = new Book("creme waffles for dummies", "Piro Lane", 24.79);

        AList booksListA = new AList();
        SLList booksListSL = new SLList();
        DLList booksListDL = new DLList();

        //listAdd AList
        System.out.println("AList:");
        booksListA.listAdd(book1);
        booksListA.listAdd(book2);
        System.out.println(booksListA.toString());

        //listRemove AList
        System.out.println("AList Remove:");
        booksListA.listRemove(1);
        System.out.println(booksListA.toString());


        //listAdd SLList
        System.out.println("SLList:");
        booksListSL.listAdd(book1);
        booksListSL.listAdd(book2);
        System.out.println(booksListSL.toString());

        //ListRemove SLList
        System.out.println("SLList Remove:");
        booksListSL.listRemove(1);
        System.out.println(booksListSL.toString());

        //ListAdd DLList
        System.out.println("DLList:");
        booksListDL.listAdd(book1);
        booksListDL.listAdd(book2);
        System.out.println(booksListDL.toString());

        //ListRemove DLList
        System.out.println("DLList Remove:");
        booksListDL.listRemove(1);
        System.out.println(booksListDL.toString());





    }
}
